package com.ms.prueba.repository.interfaces;

public interface AgeStatsProjection {

    Double getAverage();
    Double getStddev();

}
