package com.ms.prueba.repository.interfaces;

import com.ms.prueba.entity.TestEntity;

public interface TestRepository extends BaseRepository<TestEntity, Long> {
}