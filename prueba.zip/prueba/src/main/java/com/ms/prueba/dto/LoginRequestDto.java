package com.ms.prueba.dto;

// LoginRequest.java
public class LoginRequestDto {
    private String username;
    private String password;
    // getters y setters
}
