package com.ms.prueba.dto;

public interface UserDto {
    String getUsername();
    String getPassword();
    String getRol();
}
